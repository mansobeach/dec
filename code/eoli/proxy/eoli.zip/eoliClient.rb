#!/usr/bin/env ruby

# == Synopsis
#
# This is a command line client of MUIS via EOLI-SA Servlet I/F.
# ESA-ESRIN (MUIS) Multi-Mission User Information Services.
# EOLI-SA Configuration files are stored in $EOLI_CLIENT_CONFIG
#
# == Usage
# eoliClient.rb  --gip <GIPValue> --start <date> --end <date>
#   --start        <YYYY-MM-DDTHH:MM:SS>  
#   --end          <YYYY-MM-DDTHH:MM:SS>
#   --gip          <GIPValue> Extracted/Compliant with ServiceDirectory.xml
#   --fields       "FIELD_1 FIELD_2 ... FIELD_N"
#   --FIELDS       It shows all available Fields for the current query
#   --GIPS         It shows all available GIPValues from ServiceDirectory.xml
#   --CONFIG       It retrieves the EOLI Configuration
#
#   --ALL          <Prefix_Collection_Name>
#                  It retrieves All the Collections for the time interval
#
#   --keep         Instead of sending to standard output the result of the search
#                  It keeps it into a file with name:
#                  <GIP_COLLECTION>_<CREATION_DATE>_<START>_<STOP>.xml
#
#   --details      It request detailed information about the retrieved items
#   --thumbnails   It requests the available thumbnails for the retrieved items
#
#   --browse       <browse_name>   
#                  It retrieves the available browse images for the requested items
#
#   --list         It request the list of ESA Sets
#   --version      It requests the EOLI Version Info
#   --help         shows this help
#   --usage        shows the usage
# 
# == Author
# DEIMOS-Space S.L. (bolf)
#
# == Copyright
# Copyright (c) 2006 ESA - DEIMOS Space
#

require 'getoptlong'
require 'rdoc/usage'
require 'uri'
require 'open-uri'

require 'eoli/EOLICommon'
require 'eoli/EOLIClient'
require 'eoli/EOLIDataProcessor'
require 'eoli/EOLIWriterXML'
require 'eoli/EOLIConfigManager'


@@NUM_MAX_ELEMENTS = 900
@@NUM_MAX_DAYS     = 5

def main

   include EOLIDataProcessor
   include EOLICommon

   @@isVerboseMode = false
   @@isDebugMode   = false
   bGetConfig      = false
   bShowFields     = false
   bShowGIPS       = false
   bRetrThumbnails = false
   bALL            = false
   satName         = ""
   @strBrowseName  = ""
   @arrFields    = Array.new
   startDate     = ""
   endDate       = ""
   gip           = ""
   collection    = ""
   bNoConfig     = false
   @strFields     = ""
   @strGIPValue  = ""
   @bDetails     = false
   @bList        = false
   @bKeep        = false
   @bGetEoliVersion = false
   bOneProcess   = true
   
   opts = GetoptLong.new(
   ["--start", "-s",               GetoptLong::REQUIRED_ARGUMENT],   
   ["--end", "-e",                 GetoptLong::REQUIRED_ARGUMENT],   
   ["--collection", "-c",          GetoptLong::REQUIRED_ARGUMENT],
   ["--browse", "-b",              GetoptLong::REQUIRED_ARGUMENT],
   ["--fields", "-f",              GetoptLong::REQUIRED_ARGUMENT],
   ["--ONEPROCESS", "-O",          GetoptLong::NO_ARGUMENT],
   ["--Konfig", "-K",              GetoptLong::NO_ARGUMENT],
   ["--details", "-d",             GetoptLong::NO_ARGUMENT],
   ["--thumbnails", "-t",          GetoptLong::NO_ARGUMENT],
   ["--list", "-l",                GetoptLong::NO_ARGUMENT],
   ["--usage", "-u",               GetoptLong::NO_ARGUMENT],
   ["--version", "-v",             GetoptLong::NO_ARGUMENT],
   ["--help", "-h",                GetoptLong::NO_ARGUMENT],
   ["--CONFIG", "-C",              GetoptLong::NO_ARGUMENT],
   ["--Verbose", "-V",             GetoptLong::NO_ARGUMENT],
   ["--Debug", "-D",               GetoptLong::NO_ARGUMENT],
   ["--keep", "-k",                GetoptLong::NO_ARGUMENT],
   ["--FIELDS", "-F",              GetoptLong::NO_ARGUMENT],
   ["--GIPVALUES", "-G",           GetoptLong::NO_ARGUMENT],
   ["--ALL", "-A",                 GetoptLong::REQUIRED_ARGUMENT],
   ["--gip", "-g",                 GetoptLong::REQUIRED_ARGUMENT]
   )
   
   begin
      opts.each do |opt, arg|
         case opt
	         when "--Debug"         then @@isDebugMode = true
	         when "--Verbose"       then @@isVerboseMode = true
            when "--start"         then startDate    = arg
            when "--end"           then endDate      = arg
            when "--gip"           then @strGIPValue = arg
                                        satName = arg
            when "--details"       then @bDetails    = true
            when "--list"          then @bList       = true
            when "--keep"          then @bKeep       = true
	         when "--browse"        then @strBrowseName = arg
	         when "--CONFIG"        then bGetConfig   = true
            when "--ONEPROCESS"    then bOneProcess  = true
	         when "--thumbnails"    then bRetrThumbnails = true
	         when "--fields"        then @strFields    = arg
	         when "--FIELDS"        then bShowFields  = true
	         when "--GIPVALUES"     then bShowGIPS    = true
            when "--ALL"           then satName      = arg
            when "--help"          then RDoc::usage
	         when "--usage"         then RDoc::usage("usage")
            when "--version"       then @bGetEoliVersion = true
            when "--Konfig"        then bNoConfig = true
         end
      end
   rescue Exception
      exit(99)
   end   
 
   if (startDate == "" or endDate == "" or (@strGIPValue == "" and satName == "") ) and (bShowGIPS == false) and (bGetConfig == false) and
   (@bGetEoliVersion == false) and (@bList == false) then
      RDoc::usage#("usage")
   end
 
   if bGetConfig == true and bNoConfig == true then
      RDoc::usage
   end
 
   # Format the string dates to EOLI format
   if startDate != "" then
      startDate = startDate.sub("T","+")
   end

   if endDate != "" then
      endDate = endDate.sub("T","+")
   end
   
   if @@isVerboseMode == true
      STDERR.puts "\nDEIMOS-Space S.L. eoliClient ...\n"
   end

   @clientEOLI = EOLIClient.new(@@isDebugMode)  
   
   #-----------------------------------------------------------
   # LOGIN into EOLI
   ret = @clientEOLI.loginAnonymous
   response = @clientEOLI.getResponseMsg
   
   if ret == false then
      STDERR.puts "Could not log into EOLI system ! :-("
      STDERR.puts
   end
   
   if @@isVerboseMode == true then
      STDERR.puts 
      STDERR.puts response
      STDERR.puts
   end
   
   if ret == false then
      exit(99)
   end
   
   #-----------------------------------------------------------
   # LIST ESA Sets
   if @bList == true then
      ret = @clientEOLI.listESASets
      response = @clientEOLI.getResponseMsg
      arr = response.split("|")
      if ret == false then
         STDERR.puts "Could not List ESA Sets ! :-("
         STDERR.puts
      else
         ret = @clientEOLI.loadESASet(arr[0])
         if ret == false then
            STDERR.puts "Could not Load ESA Sets ! :-("
            STDERR.puts
         end
         response = @clientEOLI.getResponseMsg
         arrResponse = response.split("\n")
         arrHeader   = arrResponse[0].split("|")
         bFirst      = true
         arrResponse.each{|line|
            if bFirst == true then
               bFirst = false
               next
            end
            arrFields = line.split("|")
            i = 0
            arrFields.each{|field|
               STDERR.puts "#{arrHeader[i]} -> #{field}"
               i = i + 1
            }
            STDERR.puts "---------------------------"
         }
       
        
        
      end
      exit(0)
   end
   #-----------------------------------------------------------
   # Get EOLI Version Info
   if @bGetEoliVersion == true then
      ret = @clientEOLI.getEoliVersion
      if ret == false then
         STDERR.puts "Could not retrieve Eoli Version info ! :-("
         STDERR.puts
      end
      exit(0)
   end
   #-----------------------------------------------------------
   # Retrieve & Manage the Configuration if it has been requested explicitly
   # 
   if (satName != "" or bGetConfig == true) and bNoConfig == false then
      confManager = EOLIConfigManager.new
   
      if confManager.isAbleToCheckConfig? == true then
         getEOLIConfiguration
      
         if @@isDebugMode == true then
            confManager.setDebugMode
         end
   
         confManager.install
      else
         if bGetConfig == true then
            STDERR.puts "Other eoliClient.rb is checking the configuration"
            STDERR.puts
         end
      end
   end
   if bGetConfig == true then
      exit(0)
   end
   #-----------------------------------------------------------   
   
      
   #-----------------------------------------------------------
   
   arrGIPs        = @clientEOLI.arrGIPValues
   arrCollections = @clientEOLI.arrCollections
   # It shows all GIPValues from ServiceDirectory.xml   
   if bShowGIPS == true then
     if @@isVerboseMode == false then
         STDERR.puts arrGIPs
         STDERR.puts
      else
         arrCollections.each{|collection|
            collection.each{|field|
               print field
               print " "
            }
            STDERR.puts
         }
      end
      exit(0)
   end
   
   # Get All Collections from current ServiceDirectory.xml
   
   if satName != "" then
      if bOneProcess == true then
         getALLCollections2(satName, startDate, endDate, arrGIPs, bRetrThumbnails)
      else
         getALLCollections(satName, startDate, endDate, arrGIPs, bRetrThumbnails)
      end
   end
     
end
#===============================================================================

# Retrieve the elements using the structure of the Inventory Search result
def retrieveSearchResult(searchResult)
   arrResult    = Array.new
   collectionID = searchResult[:collectionID]
   arrGroups    = searchResult[:arrGroups]
   
   arrGroups.each{|group|
      arrResult   << @clientEOLI.inventoryRetrGroup(collectionID, group[:groupID], "APPEND")   
      response     = @clientEOLI.getResponseMsg
      if @@isVerboseMode or @@isDebugMode == true then
         STDERR.puts response
      end
   }
   return arrResult
end
#===============================================================================

def processCollection(strGIPValue, arrGIPs, startDate, endDate, bRetrThumbnails)

   # Check that the GIPValue is present in the ServiceDirectory.xml
   if arrGIPs.include?(strGIPValue) == false then
      STDERR.puts "GIPValue #{strGIPValue} is not present in ServiceDirectory.xml"
      STDERR.puts
      STDERR.puts "try #{File.basename($0)} -G  for a list of available GIPValues"
      STDERR.puts
      exit(99) 
   end
      
   # Extract the Fields required
   @arrFields = @strFields.split(" ")   
   
   structResp = @clientEOLI.inventorySearch("", strGIPValue, startDate, endDate)
   response   = @clientEOLI.getResponseMsg
   
   if @@isDebugMode == true
      STDERR.puts "-------------------------------"
      STDERR.puts response
      STDERR.puts "-------------------------------"
   end
   
   # Check whether the inventorySearch has been successful or not.
   # A "SUCCESS" message from EOLI does not mean there are ITEMs to retrieve,
   # because of this it is required an aditional method to understand whether
   # there has been a buffer overflow in the query or simply there were no Items
   # for the query performed.
   
   if @clientEOLI.hasAvailableItems? == false then
      STDERR.puts "No Items were found"
      STDERR.puts
      return
   end
    
   # Get the num of Elements retrieved by the Query
   numElements = response.split(" ")[1].to_i
   
   arrResults  = Array.new
   
   if numElements == 0 then
      startTime    = EOLICommon::getUTCTime(startDate)
      stopTime     = EOLICommon::getUTCTime(endDate)
      diffTime     = stopTime - startTime
      
      if diffTime.to_i < (@@NUM_MAX_DAYS * 24 * 60 * 60)
         STDERR.puts "No Elements found !"
         STDERR.puts
         exit(99)
      end
      arrResults = segmentDays(startDate, endDate)
   else
      if numElements > @@NUM_MAX_ELEMENTS then
         arrResults = segmentElements(startDate, endDate, numElements)
      else 
         if structResp == nil then
            STDERR.puts "Error requesting an INVENTORY_SEARCH operation"
            STDERR.puts response
            STDERR.puts
            exit(99)
         end 
         arrResults = retrieveSearchResult(structResp)           
      end
   end
   
   arrResults = arrResults.uniq
   
   #arrResults = arrResults.sort
   
#    # If it is requested only watching the Fieldnames
#    fields     = @clientEOLI.getFieldNames   
#    if bShowFields == true then
#       showFields(fields)
#       exit(0)
#    end
   
   # Show the Fields
   if @arrFields.length > 0 then
      EOLIDataProcessor::showMQuerySelectedFields(arrResults, @arrFields)
   end
   
   #-------------------------------------
   # Retrieve the details
   @base = ""
   if @bDetails == true then
      ret  = retrieveDetails(arrResults)
      if ret == false then
         STDERR.puts
         STDERR.puts "Could not retrieve Details ! :-("
         STDERR.puts
      else
         @base = getBaselineFromDetails(ret)
         if @base == false then
            STDERR.puts "Could not extract Baseline info from INV_DETAILS ! :-( "
            STDERR.puts
            exit(99)
         else
            if @@isVerboseMode == true then
               print "Baseline: ", @base, "\n\n"
            end
         end
      end

   end
   
   #-------------------------------------
   # Write Output File
   dateStart   = EOLICommon::getUTCTime(startDate)
   dateStop    = EOLICommon::getUTCTime(endDate)
   
   fileWriter = EOLIWriterXML.new(strGIPValue, dateStart, dateStop, @base, @bKeep)
   fileWriter.writeData(arrResults)   
   
   #-------------------------------------
   # Retrieve the Thumbnails
   
   if bRetrThumbnails == true then
      retrieveThumbnails(arrResults)
   end
   
   #-------------------------------------
   # Retrieve the Browse Products
   
   if @strBrowseName != ""
      retrieveBrowseImages(arrResults)
   end
   

end
#===============================================================================

# Segment Days
   
def segmentDays(strDateStart, strDateStop)
   startTime    = EOLICommon::getUTCTime(strDateStart)
   stopTime     = EOLICommon::getUTCTime(strDateStop)
   incrSecs     = @@NUM_MAX_DAYS * 24 * 60 * 60
   
   dateStart = startTime
   dateStop  = Time.utc("2000")
   dateStart = dateStart - incrSecs
   
   arrResults = Array.new
   
   while (dateStop + incrSecs) < stopTime
      dateStart = dateStart + incrSecs
      dateStop  = dateStart + incrSecs
      strStart  = EOLICommon::getStrTime(dateStart)
      strStop   = EOLICommon::getStrTime(dateStop)
            
      structResp = @clientEOLI.inventorySearch("", 
                                               @strGIPValue,
					                                strStart,
					                                strStop
						                            )
      response   = @clientEOLI.getResponseMsg
   
      if @@isVerboseMode == true
         STDERR.puts "#{response} from #{strStart} to #{strStop}"
      end
     
      # Get the num of Elements retrieved by the Query
      numElements = response.split(" ")[1].to_i
   
      if numElements == 0 then
         next
      end
      
      arr = Array.new

      if numElements > @@NUM_MAX_ELEMENTS then
         arr = segmentElements(strStart, strStop, numElements)
      else
         arr = retrieveSearchResult(structResp)
      end
      arrResults  = arrResults.concat(arr)   
   end
   
   dateStart = dateStart + incrSecs
   dateStop  = stopTime   
   strStart  = EOLICommon::getStrTime(dateStart)
   strStop   = EOLICommon::getStrTime(dateStop)
      
   structResp = @clientEOLI.inventorySearch("", 
                                            @strGIPValue,
					                             strStart,
					                             strStop
						                         )
   response   = @clientEOLI.getResponseMsg
   
   if @@isVerboseMode == true
      STDERR.puts "#{response} from #{strStart} to #{strStop}"
   end
     
   # Get the num of Elements retrieved by the Query
   numElements = response.split(" ")[1].to_i

   arr = Array.new

   if numElements > @@NUM_MAX_ELEMENTS then
      arr = segmentElements(strStart, strStop, numElements)
   else
      arr = retrieveSearchResult(structResp)
   end
   arrResults  = arrResults.concat(arr)
   
   return arrResults
end
#===============================================================================

# Segment Elements Inventory Query
# This function has been developed because of the EOLI-SA  3.0 way to provide results.
# Maybe this method should be considered as OBSOLETE.
# All results were provided in only one group and because of this, they could be requested via
# INV_RETR operation in only one request. If the number of elements was too high, there was an overflow,
# so it was required to request the results of the INV_SEARCH segmented in pieces.

def segmentElements(strDateStart, strDateStop, numRetrievedElements)
   if @isDebugMode == true then
      STDERR.puts "Segment-Elements [#{numRetrievedElements}]-> #{strDateStart} - #{strDateStop}"
   end
   
   factorSegment = (numRetrievedElements / @@NUM_MAX_ELEMENTS) + 1
   arrResponses  = Array.new
   
   startTime    = EOLICommon::getUTCTime(strDateStart)
   stopTime     = EOLICommon::getUTCTime(strDateStop)
   secsStart    = startTime.to_i
   secsStop     = stopTime.to_i
   
   secsDiffTime = secsStop - secsStart
   secsIncTime  = secsDiffTime / factorSegment
   
   i     = 1
   start = 0
   stop  = 0
   
   while i < factorSegment
      start     =  secsStart + secsIncTime*(i-1)
      stop      =  start + secsIncTime
      dateStart = Time.at(start).getutc
      dateStop  = Time.at(stop).getutc
      strStart  = EOLICommon::getStrTime(dateStart)
      strStop   = EOLICommon::getStrTime(dateStop)
      if @@isDebugMode == true then
         STDERR.puts "segment#{i} -> #{strStart} - #{strStop}"
      end
      
      structResp = @clientEOLI.inventorySearch("", @strGIPValue, strStart, strStop)
      response   = @clientEOLI.getResponseMsg

      if @@isVerboseMode == true then
         print response, " from #{dateStart} to #{dateStop}", "\n"
      end      
      arrResponses << retrieveSearchResult(structResp)
      i     = i + 1
   end
   
   start     = stop
   stop      = secsStop
   dateStart = Time.at(start).getutc
   dateStop  = Time.at(stop).getutc
   strStart  = EOLICommon::getStrTime(dateStart)
   strStop   = EOLICommon::getStrTime(dateStop)
      
   if @@isDebugMode == true then
      STDERR.puts "segment#{i} -> #{strStart} - #{strStop}"
   end
      
   structResp = @clientEOLI.inventorySearch("", @strGIPValue, strStart, strStop)
   response   = @clientEOLI.getResponseMsg
   
   if @@isVerboseMode == true then
      print response, " from #{dateStart} to #{dateStop}", "\n"
   end
      
   arrResponses << retrieveSearchResult(structResp)
      
   return arrResponses
end
#===============================================================================

# Extract the Baseline information from the Details
def getBaselineFromDetails(details)
    
   if @@isDebugMode == true and details != nil and details.class == "Hash" then
      details.each {|akey, avalue| 
         STDERR.puts "#{akey} -> #{avalue}"
      }
   end
   
   if details.key?("BASELINE") == false then
      return false
   else
      return details["BASELINE"]
   end

end
#===============================================================================

# It shows the Fields availables in EOLI for the query performed.
def showFields(fields)
   fields.each{|field|
      print "#{field.upcase} "
   }
   STDERR.puts
   STDERR.puts
   STDERR.puts
end
#===============================================================================

# Retrieve EOLI Configuration
def getEOLIConfiguration
   if @@isVerboseMode == true or @@isDebugMode == true then
      STDERR.puts "Retrieving EOLI Configuration"
      STDERR.puts
   end
   @clientEOLI.getEOLIConfig("2000-06-29+00:00:00", "2000-06-29+00:00:00")
   return
end
#===============================================================================

# Retrieve ALL Collections
def getALLCollections(satName, startDate, endDate, arrGIPs, bRetrThumbnails)
   satName = satName.upcase
   arrGIPs.each{|gipValue|
#      if gipValue.upcase.include?(satName) == true
      if gipValue.upcase.index(satName) == 0
         cmd = %Q{eoliClient.rb -g #{gipValue} -s #{startDate} -e #{endDate} -k}
         if @@isVerboseMode == true then
            cmd = %Q{#{cmd} -V}
         end
         if @@isDebugMode == true then
            cmd = %Q{#{cmd} -D}
         end
         if @bDetails == true then
            cmd = %Q{#{cmd} -d}
         end         
         if bRetrThumbnails == true then
            cmd = %Q{#{cmd} -t}
         end
         if @strBrowseName != "" then
            cmd = %Q{#{cmd} -b DEFAULT}
         end
         
         STDERR.puts cmd
         ret = system(cmd)
         if ret == false then
            STDERR.puts "Failed executing eoliClient.rb"
         end
      end
   }
   exit(0)
end
#===============================================================================

# Retrieve ALL Collections
def getALLCollections2(satName, startDate, endDate, arrGIPs, bRetrThumbnails)
   satName = satName.upcase
   arrGIPs.each{|gipValue|
      if gipValue.upcase.index(satName) == 0
         if @@isVerboseMode == true
            STDERR.puts "Processing #{gipValue} Collection"
         end
         processCollection(gipValue, arrGIPs, startDate, endDate, bRetrThumbnails)
      end
   }
   
   @clientEOLI.logout  
   response = @clientEOLI.getResponseMsg

   exit(0)
end
#===============================================================================

# Retrieve Thumbnails for the Elements requested by an Inventory Retrieve
# Right now it has been implemented to perform this operation just once, but
# the full loop (perform INV_DETAILS for all the retrieved elements) could be performed.
def retrieveDetails(arrResults)
   arrResults = arrResults.flatten
   
   if arrResults.length == 0 then
      STDERR.puts "eoliClient::details -> No elements to retrieve details"
      return
   end
   
   if @@isVerboseMode == true then
      STDERR.puts
   end
   
   
   arrResults.each{|row|    
      desc        = row["ACQUISITIONDESCRIPTOR"]
      collection  = row["COLLECTION"] 
      start       = EOLICommon::getStrTime2(row["START"])
      stop        = EOLICommon::getStrTime2(row["STOP"])
      mission     = row["MISSION"]
      sensor      = row["SENSOR"]
      product     = row["PRODUCT"]
      
      ret = @clientEOLI.details(desc, collection)
      
      if @@isVerboseMode == true then
         print "Details requested for #{collection} -> #{desc}"
      end
      
      if ret == false then
         next
      end
      if @@isVerboseMode == true then
         STDERR.puts
      end	
      return ret
   }
   return false
end
#===============================================================================

# Retrieve Thumbnails for the Elements requested by an Inventory Retrieve
def retrieveThumbnails(arrResults)
   arrResults = arrResults.flatten
   
   if arrResults.length == 0 then
      #STDERR.puts "retrieveThumbnails no ELEMENTS"
      return
   end
   
   arrResults.each{|row|    
      desc        = row["ACQUISITIONDESCRIPTOR"]
      collection  = row["COLLECTION"] 
      start       = EOLICommon::getStrTime2(row["START"])
      stop        = EOLICommon::getStrTime2(row["STOP"])
      mission     = row["MISSION"]
      sensor      = row["SENSOR"]
      product     = row["PRODUCT"]
      thumbURL    = row["THUMBNAIL_URL"]
      
      if thumbURL != "" and thumbURL != nil then
         ret = retrieveURL(thumbURL)
         if ret == false then
            STDERR.puts "Could not retrieve #{thumbURL}"
         end
         next
      else

#       ret = @clientEOLI.thumbnail(desc, 
#                                   collection,
# 			                         mission,
# 			                         sensor,
# 			                         product,
#                                   start,
# 			                         stop)
      
         ret = @clientEOLI.thumbnail2(desc, collection)
      
         if ret == false then
            if @@isVerboseMode == true then
	            STDERR.puts "No thumbnail available for #{desc}"
	         end
         else
            STDERR.puts "thumbnail encontrado !!!!!!!"
	         exit
         end
      end
      
   }
end
#===============================================================================

# It retrieves an URL
def retrieveURL(url)
   if @@isDebugMode == true then
      STDERR.puts "Retrieving -> #{url}"
   end
   arr      = nil
   uri      = URI.parse(url)
   arrUri   = uri.path.split("/")
   filename = arrUri.slice(arrUri.length-1)
   
   if @@isVerboseMode == true then
      STDERR.puts filename
   end
   
   begin
      open(uri) do |f|
   #       STDERR.puts f.status
   #       STDERR.puts f.content_type
   #       STDERR.puts f.content_encoding
   #       STDERR.puts f.meta
         f.binmode
         arr = f.read
      end
   rescue Exception => exception
      if @@isVerbode == true or @@isDebugMode == true then
         STDERR.puts "Could not retrieve #{uri.path} !"
      end
      if @@isDebugMode == true then
         STDERR.puts exception.backtrace
      end
      return false
   end

   aFile = nil     
   begin
      aFile = File.new(filename, File::CREAT|File::WRONLY)
   rescue Exception
      STDERR.puts
      STDERR.puts "Fatal Error in eoliClient::retrieveURL"
      STDERR.puts "Could not create file #{filename} in #{Dir.pwd}"
      exit(99)
   end
      
   aFile.binmode
   aFile.print arr
   aFile.flush
   aFile.close
   return true
end
#===============================================================================
def retrieveBrowseImages(arrResults)
   arrResults = arrResults.flatten
   
   if arrResults.length == 0 then
      return
   end
   
   arrResults.each{|row|    
      desc        = row["ACQUISITIONDESCRIPTOR"]
      collection  = row["COLLECTION"] 
      start       = EOLICommon::getStrTime2(row["START"])
      stop        = EOLICommon::getStrTime2(row["STOP"])
      mission     = row["MISSION"]
      sensor      = row["SENSOR"]
      product     = row["PRODUCT"]

#       ret = @clientEOLI.browseImage(desc, 
#                                   collection,
# 			                           @strBrowseName,
# 			                           mission,
# 			                           sensor,
# 			                           product,
#                                   start,
# 			                           stop)

      ret = @clientEOLI.browseImage2(desc, 
                                    collection,
			                           @strBrowseName)
      
      if ret == false then
         if @@isVerboseMode == true then
	         STDERR.puts "No Browse Image available for #{desc}"
	      end
      else
         if @@isVerboseMode == true then
	         STDERR.puts "Browse Image retrieved for #{desc}"
	      end      
      end
      
   }

end
#===============================================================================
# Start of the main body
main
# End of the main body
#===============================================================================
