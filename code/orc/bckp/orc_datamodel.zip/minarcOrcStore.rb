#!/usr/bin/env ruby

# == Synopsis
#
# This is a MINARC command line tool that archives a given file. 
# If such file or a file with exactly same filename is already 
# archived in the system, an error will be raised.
# 
# 
# -f flag:
#
# Mandatory flag. This option is used to specify the file to be archived. 
# File must be specified with the full path location.
#
#
# -t flag:
#
# Optional flag. This flag is used to specify the file-type of the file to be archived.
# By default MINARC will determine the file-type automatically, nevertheless 
# such classification may be overidden using this parameter. 
# In case MINARC fails to determine the file-type, it shall be specified by this flag. 
#
#
# -trigger flag:
# Optional flag. Specifies the name of the related trigger product file.
#
# -m flag:
#
# Optional flag. This flag is used to "move" specified source file to the Archive.
# Source file location must be in the same Archive filesystem ($MINARC_ARCHIVE_ROOT).
# By default minArcStore.rb copies source file from the specified location and optionally
# once it is archived it deletes it (see "-d" flag). This flag is not compatible with -d flag.
#
#
# DISABLED # -d flag: 
#
# Optional flag. This flag is used to delete specified source file after a successful Archiving.
# If file is not archived successfully it is not deleted. This flag is not compatible with -m flag.
# 
#
# -U flag:
#
# Optional flag. This is the Unpack flag. It is used to unpack/decompress file before archiving it.
# The file format must be supported to perform the unpack action.
# The following formats are supported:
# - zip
# - tar
# - tgz
# - gz
#
#
# -T flag:
#
# This flag is used to show all archived file-types.
#
#
# == Usage
# minArcStore.rb -f <full_path_file> [-t type-of-the-file] [-d]
#     --file <full_path_file>    specifies the file to be archived
#     --type <file-type>         specifies the file-type of the file to be archived
#     --trigger <file-name>      specifies the name of the related trigger files(ORC MINARC)
# disabled #     --delete                   enable delete flag
#     --move                     its moves the file to the Archive
#     --Unpack                   enable file unpacking for supported extensions
#     --Types                    it shows all file-types archived
#     --help                     shows this help
#     --usage                    shows the usage
#     --Debug                    shows Debug info during the execution
#     --version                  shows version number
# 
# == Author
# DEIMOS-Space S.L.
#
# == Copyright
# Copyright (c) 2008 ESA - DEIMOS Space S.L.
#

#########################################################################
#
# === Mini Archive Component (MinArc)
#
# CVS: $Id: minarcOrcStore.rb,v 1.2 2008/05/30 10:32:43 decdev Exp $
#
#########################################################################

require 'getoptlong'
require 'rdoc/usage'

require "orc/ORCFileArchiver"
require "minarc/MINARC_DatabaseModel"

# Global variables
@@dateLastModification = "$Date: 2008/05/30 10:32:43 $"   # to keep control of the last modification
                                       # of this script
                                       # execution showing Debug Info


# MAIN script function
def main

   @full_path_filename     = ""
   @filename               = ""
   @filetype               = ""
   @triggerName            = ""
   @isDebugMode            = false
   @bDelete                = false
   @bMove                  = false
   @bUnpack                = false
   bShowFileTypes          = false
   
   opts = GetoptLong.new(
     ["--file", "-f",            GetoptLong::REQUIRED_ARGUMENT],
     ["--type", "-t",            GetoptLong::REQUIRED_ARGUMENT],
     ["--trigger",               GetoptLong::REQUIRED_ARGUMENT],
     ["--Types", "-T",           GetoptLong::NO_ARGUMENT],
#     ["--delete", "-d",          GetoptLong::NO_ARGUMENT],
     ["--move", "-m",            GetoptLong::NO_ARGUMENT],
     ["--Debug", "-D",           GetoptLong::NO_ARGUMENT],
     ["--Unpack", "-U",          GetoptLong::NO_ARGUMENT],
     ["--usage", "-u",           GetoptLong::NO_ARGUMENT],
     ["--version", "-v",         GetoptLong::NO_ARGUMENT],
     ["--help", "-h",            GetoptLong::NO_ARGUMENT]
     )
    
   begin
      opts.each do |opt, arg|
         case opt      
            when "--Debug"     then @isDebugMode = true
#            when "--delete"    then @bDelete     = true
            when "--move"      then @bMove       = true
            when "--version" then	    
               print("\nESA - DEIMOS-Space S.L. ", File.basename($0), " $Revision: 1.2 $  [", @@dateLastModification, "]\n\n\n")
               exit(0)
	         when "--file"          then @full_path_filename = arg.to_s
	         when "--type"          then @filetype           = arg.to_s
	         when "--trigger"       then @triggerName        = arg.to_s
            when "--Types"         then bShowFileTypes      = true
			   when "--help"          then RDoc::usage
	         when "--usage"         then RDoc::usage("usage")
            when "--Unpack"        then @bUnpack = true
         end
      end
   rescue Exception
      exit(99)
   end
 
   if bShowFileTypes == true then
      arrFiles = ArchivedFile.getFileTypes()
      arrFiles.each{|aFile|
         puts aFile.filetype
      }
      exit(0)
   end  

   if @bDelete == true and @bMove == true then
      RDoc::usage("usage")
   end

   if @full_path_filename == "" then
      RDoc::usage("usage")
   end
   
   if @full_path_filename.slice(0,1) != "/" then
      puts
      puts "File must be specified with a full path"
      puts
      exit(99)
   end

   if File.directory?(@full_path_filename) == true and @bUnpack == true then
      puts
      puts "Unpack flag cannot be used with a directory !"
      puts
      exit(99)
   end

   @filename = File.basename(@full_path_filename)

   # Check if it is a supported file for unpackaging 
   if @bUnpack == true then
      extension = File.extname(@filename).to_s.downcase
      bSupported = false
      case extension
         when ".zip"  then bSupported = true
         when ".tar"  then bSupported = true
         when ".gz"   then bSupported = true
         when ".tgz"  then bSupported = true
      end

      if bSupported == false then
         puts "#{fileName} is not supported for unpacking ! :-("
         puts
         exit(99)
      end
   end

#   @logger  = CUC::DEC_Logger.new("getFromInterface")


   archiver  = ORCFileArchiver.new(@bMove)
   
   if @isDebugMode == true then
      archiver.setDebugMode
   end

   ret = archiver.archive(@full_path_filename, @filetype, @triggerName, @bDelete, @bUnpack)
   
   if ret == false then
      puts
      puts "MINARC could not archive #{@filename}"
      puts
      exit(99)
   end
 
   exit(0)

end

#-------------------------------------------------------------


#-------------------------------------------------------------

#===============================================================================
# Start of the main body
main
# End of the main body
#===============================================================================
