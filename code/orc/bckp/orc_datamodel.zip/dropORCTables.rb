#!/usr/bin/env ruby

require 'ORC_DataModel'
require 'ORC_Migrations'

puts "START"

if ProductionTimeline.table_exists?() then
   CreateProductionTimelines.down
end

if ObsoleteTriggerProduct.table_exists?() then
   CreateObsoleteTriggerProducts.down
end

if SuccessfulTriggerProduct.table_exists?() then
   CreateSuccessfulTriggerProducts.down
end

if FailingTriggerProduct.table_exists?() then
   CreateFailingTriggerProducts.down
end

if OrchestratorQueue.table_exists?() then
   CreateOrchestratorQueue.down
end

if TriggerProduct.table_exists?() then
   CreateTriggerProducts.down
end

puts "END"
